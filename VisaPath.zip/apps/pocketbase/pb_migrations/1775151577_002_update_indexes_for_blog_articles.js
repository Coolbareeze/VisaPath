/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("blog_articles");
  collection.indexes.push("CREATE UNIQUE INDEX idx_blog_articles_slug ON blog_articles (slug)");
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("blog_articles");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_blog_articles_slug"));
  return app.save(collection);
})